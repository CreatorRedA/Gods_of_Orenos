# Support

## Discord

-   You can find us on [Discord](https://discord.gg/2BvnM4R).

## GitHub

-   You can create an issue in [GitHub](https://github.com/vis2k/Mirror/issues)
-   You can also contribute with Pull Requests...see [Contributing](https://github.com/vis2k/Mirror/blob/master/CONTRIBUTING.md)
