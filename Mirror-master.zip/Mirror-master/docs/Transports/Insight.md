# Insight  
Insight is a Simple Message Server for Unity based on Mirror. It can operate on its network connection or alongside a NetworkMannager. Inspired by MasterServerFramework it can be expanded with flexible modules.

Get it now on [GitHub](https://github.com/uweenukr/Insight)!
