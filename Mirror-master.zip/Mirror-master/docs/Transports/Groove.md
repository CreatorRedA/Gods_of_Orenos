# Groove

A WebSockets transport layer for Mirror. WebGL is fully supported (for Mirror clients). Please try to break it.

## Features

* Run a Mirror client (including WebGL) and server (on Windows, macOS or Linux) using WebSockets
* Use the power of Mirror to develop your game while being able to support the extreme reach of the WebGL target

Get it now on [GitHub](https://github.com/Katori/Groove)!
