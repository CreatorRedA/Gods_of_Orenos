# Samples Overview

General description of Samples

-   [Pong](Pong)  
    A simple example for "How to built a multiplayer game with Mirror" is Pong,
    which is included in the AssetStore package of Mirror. It illustrates the
    usage of NetworkManager, NetworkManagerHUD, NetworkBehaviour,
    NetworkIdentity, NetworkTransform, NetworkStartPosition and
    NetworkingAttributes.
