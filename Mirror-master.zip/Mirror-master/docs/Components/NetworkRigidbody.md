# NetworkRigidbody

General description of NetworkRigidbody
