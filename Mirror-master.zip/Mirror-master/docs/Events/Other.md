# Other Events Overview

General description of Other Events

-   **OnValidate**  
    Something about this
-   **OnDestroy**  
    Something about this
